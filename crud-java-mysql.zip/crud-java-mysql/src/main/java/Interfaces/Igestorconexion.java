
package Interfaces;


public interface Igestorconexion {
    void conectar();
    void desconectar();
    boolean testearconexion();
    
}
